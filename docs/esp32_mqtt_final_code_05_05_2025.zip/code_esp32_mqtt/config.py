# for use in peralta 103: 

TEAM = 'EGR314/Team301/'
TOPIC_HB=TEAM+'heartbeat'
TOPIC_PUB = TEAM+'PUB'
TOPIC_SUB = TEAM+'SUB'
TOPIC_MS = TEAM+'MS'
TOPIC_SPEED = TEAM+'SPEED'
MQTT_SERVER = '52.25.206.167'
MQTT_USER='student'
MQTT_PASSWORD='egr3x4'
WIFI_SSID = 'photon'
WIFI_PASSWORD='particle'


# for use at home with computer: 
'''
TEAM = 'EGR314/Team301/'
TOPIC_HB=TEAM+'heartbeat'
TOPIC_PUB = TEAM+'PUB'
TOPIC_SUB = TEAM+'SUB'
MQTT_SERVER = ''
MQTT_USER=''
MQTT_PASSWORD=''
WIFI_SSID = 'SomeCuteBears'
WIFI_PASSWORD='StevenGarbidor3000'
'''