# Derived from: 
# * https://github.com/peterhinch/micropython-async/blob/master/v3/as_demos/auart.py
# * https://github.com/tve/mqboard/blob/master/mqtt_async/hello-world.py
# * https://github.com/peterhinch/micropython-mqtt
# * https://github.com/embedded-systems-design/external_pycopy-lib


import ssl

from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import wifi_led, blue_led, config
import uasyncio as asyncio
from machine import UART
from machine import Pin
import time
from config import *

# from machine import Pin

led2 = Pin(1, Pin.OUT)
safety = 0
speed = 0
mqttIn = ''

MAX_MESSAGE_LEN=64 # max length of message in bytes
team = [b'G',b'H',b'B',b'S'] # all possible team identifiers
id = b'G' # my team identifier
broadcast = [b'X'] # ID to broadcast to all team members

# initialize a new UART class
uart = UART(2, 9600,tx=17,rx=16)
# run the init method with more details including baudrate and parity
uart.init(9600, bits=8, parity=None, stop=1) 
# define pin 2 as an output with name led. (Pin 2 is connected to the ESP32-WROOM dev board's onboard blue LED)
# led = Pin(2,Pin.OUT)
led2 = Pin(1,Pin.OUT) # sets a second LED to correspond to heartbeat 

messageComplete = False


def send_message(message):
    print('ESP: send message')
    uart.write(message)
    messageComplete = False
    # send_queue.append(message)

def handle_message(message):
    my_string = message.decode('utf-8')
    print('ESP: handling my message',message)
    # message-handling code: 
    # check if I'm the receiver
    receiver = IDcheck(message[3:4])
    sender = IDcheck(message[2:3])
    
    if receiver =="Greetis": 
        #store the value given and display it to wifi -- REMEMBER: all values are being passed as characters, including the numbers
        if sender == "Smith":
            global safety
            safety = message[4:len(message) - 2].decode('utf-8')
            print("message to send to wifi: ")
            print(safety)    
        if sender == "Bohart": 
            global speed
            speed = message[4:len(message) - 2].decode('utf-8')
            print("message to send to wifi")
            print(speed)
    # check pass cases (pretty much just if sender is julia, pass the message): 
    elif receiver == "Smith" or receiver == "Heafey" or receiver == "Bohart": 
        print("passing message along: ")
        print(message)
        send_message(message)
        print("message passed along")
    else: 
        print("message not meant to pass through here. trashing...")
        message = b''
        print("message trashed")
    print('message handled: ', message)
    message = b'' # dispose of message, if not done already
    

async def process_rx():
    stream = b'' 
    message = b''
    send_queue = []
    receiving_message=False
    messageComplete = False

    while True:
        # read one byte
        c = uart.read(1)
        # if c is not empty:
        if c is not None:

            stream+=c
            try:
                if stream[-2:]==b'AZ': # start bytes
                    print('ESP: message start:')
                    message=stream[-2:-1]
                    receiving_message=True
            except IndexError:
                pass
            try:
                if stream[-2:]==b'YB': # end bytes
                    message+=stream[-1:]
                    stream=b''
                    receiving_message = False
                    messageComplete = True
                    print('ESP: message received:',message)
                    await asyncio.sleep(5)
                    handle_message(message)
                    # clear message
                    message = b''
                    led2.value(led2.value()^1)
            
            except IndexError:
                pass
            
            if receiving_message:
                message+=c

                if len(message)==3: # checks whether sender is in team
                    if not (message[2:3] in team):
                        print('ESP: sender not in team')
                    else:
                        print('ESP: sender in team')
                        # then check whose message is is -- create function IDcheck
                        sender = IDcheck(message[2:3])
                        print("sender is " + sender)

                if len(message)==4: # checks whether receiver is in team
                    if not (message[3:4] in team): # or message[4] == broadcast):
                        print('ESP: receiver not in team')
                        message = b''
                        print("message trashed")
                    elif (message[3:4] in broadcast): 
                        print('ESP: message is Broadcast')
                    else:
                        print('ESP: receiver in team')
                        # use IDcheck function here as well
                        receiver = IDcheck(message[3:4])
                        print("receiver is " + receiver)

                if len(message)>MAX_MESSAGE_LEN: # checks length of message is valid
                    receiving_message = False
                    print('ESP: Message size invalid, aborting')
                    message = b''
                    print("message trashed")

        await asyncio.sleep_ms(10)    

def IDcheck(byte): #checks ID of sender or receiver
    person = ''
    if byte == b'G': 
        person = 'Greetis'
    elif byte == b'H': 
        person = 'Heafey'
    elif byte == b'B': 
        person = 'Bohart'
    elif byte == b'S':
        person = 'Smith'
    else: 
        pass
    #print("ID is " + person)
    return person


MAXTX = 4
'''
uart = UART(2, 9600,tx=17,rx=16)
uart.init(9600, bits=8, parity=None, stop=1,flow=0) # init with given parameters

async def receiver():
    b = b''
    print("receiver method called")
    sreader = asyncio.StreamReader(uart)
    while True:
        res = await sreader.read(1)
        if res==b';':
            b+=res
            await client.publish(TOPIC_PUB, b, qos=1)

            print('published', b)
            b = b''
        else:
            b+=res
'''
# Subscription callback
def sub_cb(topic, msg, retained):
    global mqttIn
    mqttIn = msg.decode()
    print("message from MQTT: ", mqttIn)
    print(f'Topic: "{topic.decode()}" Message: "{msg.decode()}" Retained: {retained}')

    #uart.write(msg)
    # time.sleep(.01)


# Demonstrate scheduler is operational.
async def heartbeatMSSG():
    while True:
        print('ESP: sending')
        uart.write(b'AZBG100YB')
        await asyncio.sleep(5)
        await asyncio.sleep(5)
        #print("heart beating")

async def sendingMQTT():
    global mqttIn
    while True: 
        mssgOUT = b'AZ' + b'G?' + mqttIn + b'YB' # who am i sending this data to?
        print('sending MQTT message: ', mssgOUT)
        uart.write(mssgOUT)
        onesecond = 0.0
        while onesecond < 1.0 and mssgOUT != b'AZG?YB': # exempts default message
            await asyncio.sleep(0.1)
            led2.value(0)
            await asyncio.sleep(0.1)
            led2.value(1)
            onesecond += 0.2
        await asyncio.sleep(2)

async def heartbeatLED(): 
    while True: 
        led2.value(0)
        await asyncio.sleep(5)
        led2.value(1)
        await asyncio.sleep(5)

async def wifi_han(state):
    wifi_led(not state)
    print('Wifi is ', 'up' if state else 'down')
    await asyncio.sleep(1)

# If you connect with clean_session True, must re-subscribe (MQTT spec 3.1.2.4)
async def conn_han(client):
    await client.subscribe(TOPIC_SUB, 1)
    print("successfully subscribed to "+ TOPIC_SUB)

async def main(client):
    global mqttIn
    try:
        print("trying to connect")
        await client.connect()
        print("connection successful")
    except OSError:
        print('Connection failed.')
        return
    #asyncio.create_task(receiver())

    n = 0
    while True:
        global safety
        global speed
        await asyncio.sleep(5)
        print('publish', n)
        # If WiFi is down the following will pause for the duration.
        await client.publish(TOPIC_HB, '{} {}'.format(n, client.REPUB_COUNT), qos = 1)
        await client.publish(TOPIC_MS, '{} {}'.format(safety, client.REPUB_COUNT), qos = 1)
        await client.publish(TOPIC_SPEED, '{} {}'.format(speed, client.REPUB_COUNT), qos = 1)
        print(n, " published")
        n += 1

# Define configuration

config['server'] = MQTT_SERVER
config['ssid']     = WIFI_SSID
config['wifi_pw']  = WIFI_PASSWORD

config['ssl']  = True
# read in DER formatted certs & user key
with open('certs/student_key.pem', 'rb') as f:
    key_data = f.read()
with open('certs/student_crt.pem', 'rb') as f:
    cert_data = f.read()
with open('certs/ca_crt.pem', 'rb') as f:
    ca_data = f.read()
ssl_params = {}
ssl_params["cert"] = cert_data
ssl_params["key"] = key_data
ssl_params["cadata"] = ca_data
ssl_params["server_hostname"] = MQTT_SERVER
ssl_params["cert_reqs"] = ssl.CERT_REQUIRED
config["time_server"] = MQTT_SERVER
config["time_server_timeout"] = 10

config['ssl_params']  = ssl_params

config['subs_cb'] = sub_cb
config['wifi_coro'] = wifi_han
config['connect_coro'] = conn_han
config['clean'] = True
config['user'] = MQTT_USER
config["password"] = MQTT_PASSWORD

# Set up client
MQTTClient.DEBUG = True  # Optional
client = MQTTClient(config)

# asyncio.create_task(heartbeatMSSG())
asyncio.create_task(heartbeatLED())
asyncio.create_task(process_rx())
asyncio.create_task(sendingMQTT())

try:
    asyncio.run(main(client))
finally:
    client.close()  # Prevent LmacRxBlk:1 errors
    asyncio.new_event_loop()

    